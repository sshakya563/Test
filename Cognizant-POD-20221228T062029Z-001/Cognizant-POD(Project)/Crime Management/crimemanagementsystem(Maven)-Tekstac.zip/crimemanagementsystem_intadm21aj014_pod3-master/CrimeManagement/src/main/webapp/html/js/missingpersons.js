function hide() {
    document.getElementById("details").style.display = "none";
}

function details(){
    document.getElementById("details").style.display = "block";
}